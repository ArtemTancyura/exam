<?php   get_header();?>

    <div class="site-content clearfix">

    <div class="container">
        <img src="<?php bloginfo('template_directory'); ?>/img/404-page.jpg" alt="404">
    </div>
    </div>

<?php get_footer(); ?>