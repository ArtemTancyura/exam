<div class="sidebar col-xs-3 col-sm-3 col-md-3 col-lg-3">
    <?php dynamic_sidebar('search-form'); ?>
    <?php dynamic_sidebar('category'); ?>
    <?php dynamic_sidebar('recent_news'); ?>
 <?php dynamic_sidebar('tags'); ?>
</div>